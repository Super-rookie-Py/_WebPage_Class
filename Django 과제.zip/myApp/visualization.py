import folium
import pandas as pd
from plotly.offline import plot
from plotly.graph_objs import Scatter
import plotly.express as px
class Visualization:

    def __init__(self):
        self.df = pd.read_csv('./data/older_population.csv')
        self.geo_data = './data/seoul-dong.geojson'
        self.covid_data = pd.read_csv('./data/covid_data.csv')

    def get_figure(self, area):
        center = [37.541, 126.986]

        m = folium.Map(location = center, zoom_start = 10)

        if area is None or area =='동':
            folium.Choropleth(
                geo_data = self.geo_data,
                data = self.df,
                columns = ('동', '인구'),
                key_on = 'feature.properties.동',
                fill_color = 'BuPu',
                legend_name = "노령 인구수"
            ).add_to(m)

            figure = folium.Figure()
            m.add_to(figure)
            figure.render()

            return figure
        elif area == '구':
            df_adm = self.df.groupby(['구'])['인구'].sum().to_frame().reset_index()

            folium.Choropleth(
                geo_data=self.geo_data,
                data= df_adm,
                columns=('구', '인구'),
                key_on='feature.properties.구',
                fill_color='BuPu',
                legend_name="노령 인구수"
            ).add_to(m)

            figure = folium.Figure()
            m.add_to(figure)
            figure.render()

            return figure
        # else:
        #     m = folium.Map(
        #         location=[37.568319, 126.985664],
        #         tiles='Stamen Terrain',
        #         zoom_start=13
        #     )
        #
        #     folium.Marker(
        #         [37.568319, 126.985664],
        #         popup='Seoul Station',
        #     ).add_to(m)
        #
        #     figure = folium.Figure()
        #     m.add_to(figure)
        #     figure.render()
        #
        #     return figure

    def plot_view(self):
        data = self.covid_data.query("iso_code == 'CHN'")
        data_set = data.groupby(['Date'])['Confirmed'].sum().to_frame().reset_index()
        x_data = data_set['Date']
        y_data = data_set['Confirmed']
        plot_div = plot([Scatter(x=x_data, y=y_data, name='test', mode = 'markers',
                                 marker=dict(
                                     size=16,
                                     color=y_data,
                                     colorscale='Viridis',
                                     showscale=True
                                 ),
                                 opacity=0.8)], output_type='div')
        return plot_div
